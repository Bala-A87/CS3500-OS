#! /bin/bash

ls -d */